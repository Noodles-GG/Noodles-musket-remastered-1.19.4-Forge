package net.noodles.noodlesmusketrm.configuration;

import net.minecraftforge.common.ForgeConfigSpec;

public class MusketDamageConfiguration {
	public static final ForgeConfigSpec.Builder BUILDER = new ForgeConfigSpec.Builder();
	public static final ForgeConfigSpec SPEC;
	public static final ForgeConfigSpec.ConfigValue<Double> DAMAGE_NUMBER;
	public static final ForgeConfigSpec.ConfigValue<Double> MULTI;
	public static final ForgeConfigSpec.ConfigValue<Double> AMOUNT;
	public static final ForgeConfigSpec.ConfigValue<Double> DAMAGE_MELEE;
	public static final ForgeConfigSpec.ConfigValue<Double> SLOW_LEVEL;
	public static final ForgeConfigSpec.ConfigValue<Double> OFFSET_INTERVAL;
	public static final ForgeConfigSpec.ConfigValue<Double> BULLET_SPEED;
	public static final ForgeConfigSpec.ConfigValue<Boolean> FLAME;
	public static final ForgeConfigSpec.ConfigValue<Boolean> BREAK_WEAK_BLOCK;
	public static final ForgeConfigSpec.ConfigValue<Double> RANGE;
	public static final ForgeConfigSpec.ConfigValue<Boolean> ONLY_AFFECT_PLAYER;
	public static final ForgeConfigSpec.ConfigValue<Double> OTTOMAN_LOAD_FASTER;
	public static final ForgeConfigSpec.ConfigValue<Boolean> OTTOMAN_RESISTANCE;
	static {
		BUILDER.push("Musket Damage");
		DAMAGE_NUMBER = BUILDER.comment("The actual damage is usually a bit lower than this value").define("base_damage", (double) 16);
		BUILDER.pop();
		BUILDER.push("Load Speed Multi");
		MULTI = BUILDER.define("speed_multi", (double) 0.8);
		BUILDER.pop();
		BUILDER.push("Smoke Amount");
		AMOUNT = BUILDER.define("amount_of_smoke", (double) 12);
		BUILDER.pop();
		BUILDER.push("Melee Damage");
		DAMAGE_MELEE = BUILDER.define("melee_damage", (double) 5);
		BUILDER.pop();
		BUILDER.push("Slowness Duiring Cleaning");
		SLOW_LEVEL = BUILDER.define("slow_level", (double) 2);
		BUILDER.pop();
		BUILDER.push("Ballistic Offset Interval");
		OFFSET_INTERVAL = BUILDER.comment("It's a interval,random choose each time").define("offset_interval", (double) 0);
		BUILDER.pop();
		BUILDER.push("Bullet Speed");
		BULLET_SPEED = BUILDER.define("bullet_speed", (double) 8);
		BUILDER.pop();
		BUILDER.push("Bullet Flame");
		FLAME = BUILDER.comment("test,not recommend to open").define("flame", false);
		BUILDER.pop();
		BUILDER.push("Break Block");
		BREAK_WEAK_BLOCK = BUILDER.comment("break_weak_block_glass_eg").define("break_weak_block", false);
		BUILDER.pop();
		BUILDER.push("Flags");
		RANGE = BUILDER.comment("range_buff").define("range", (double) 32);
		ONLY_AFFECT_PLAYER = BUILDER.define("affect_player_only", true);
		OTTOMAN_LOAD_FASTER = BUILDER.comment("percent_hot_biome").define("load_faster_ottoman", (double) 0.2);
		OTTOMAN_RESISTANCE = BUILDER.comment("in_hot_biome").define("resistance_ottoman", true);
		BUILDER.pop();

		SPEC = BUILDER.build();
	}

}


package net.noodles.noodlesmusketrm.item;

import net.noodles.noodlesmusketrm.procedures.TESTSHOOTProcedure;
import net.noodles.noodlesmusketrm.procedures.MeleeProcedure;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.InteractionHand;

public class NetheriteMusketItem extends Item {
	public NetheriteMusketItem() {
		super(new Item.Properties().durability(2031).rarity(Rarity.UNCOMMON));
	}

	@Override
	public InteractionResultHolder<ItemStack> use(Level world, Player entity, InteractionHand hand) {
		InteractionResultHolder<ItemStack> ar = super.use(world, entity, hand);
		ItemStack itemstack = ar.getObject();
		double x = entity.getX();
		double y = entity.getY();
		double z = entity.getZ();
		TESTSHOOTProcedure.execute(world, x, y, z, entity);
		return ar;
	}

	@Override
	public boolean hurtEnemy(ItemStack itemstack, LivingEntity entity, LivingEntity sourceentity) {
		boolean retval = super.hurtEnemy(itemstack, entity, sourceentity);
		MeleeProcedure.execute(entity);
		return retval;
	}
}

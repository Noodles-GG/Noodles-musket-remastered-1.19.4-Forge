
package net.noodles.noodlesmusketrm.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class BarrelItem extends Item {
	public BarrelItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}


/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.noodles.noodlesmusketrm.init;

import org.lwjgl.glfw.GLFW;

import net.noodles.noodlesmusketrm.network.OpenLoadMessage;
import net.noodles.noodlesmusketrm.NoodlesmusketrmMod;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.Minecraft;
import net.minecraft.client.KeyMapping;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = {Dist.CLIENT})
public class NoodlesmusketrmModKeyMappings {
	public static final KeyMapping OPEN_LOAD = new KeyMapping("key.noodlesmusketrm.open_load", GLFW.GLFW_KEY_R, "key.categories.ui") {
		private boolean isDownOld = false;

		@Override
		public void setDown(boolean isDown) {
			super.setDown(isDown);
			if (isDownOld != isDown && isDown) {
				NoodlesmusketrmMod.PACKET_HANDLER.sendToServer(new OpenLoadMessage(0, 0));
				OpenLoadMessage.pressAction(Minecraft.getInstance().player, 0, 0);
			}
			isDownOld = isDown;
		}
	};

	@SubscribeEvent
	public static void registerKeyMappings(RegisterKeyMappingsEvent event) {
		event.register(OPEN_LOAD);
	}

	@Mod.EventBusSubscriber({Dist.CLIENT})
	public static class KeyEventListener {
		@SubscribeEvent
		public static void onClientTick(TickEvent.ClientTickEvent event) {
			if (Minecraft.getInstance().screen == null) {
				OPEN_LOAD.consumeClick();
			}
		}
	}
}

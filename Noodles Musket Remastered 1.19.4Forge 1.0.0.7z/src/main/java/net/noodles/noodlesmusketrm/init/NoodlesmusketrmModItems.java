
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.noodles.noodlesmusketrm.init;

import net.noodles.noodlesmusketrm.item.ThroughBarItem;
import net.noodles.noodlesmusketrm.item.TESTItem;
import net.noodles.noodlesmusketrm.item.NetheriteMusketItem;
import net.noodles.noodlesmusketrm.item.MusketNetheriteItem;
import net.noodles.noodlesmusketrm.item.BarrelItem;
import net.noodles.noodlesmusketrm.item.BASEItem;
import net.noodles.noodlesmusketrm.item.AmmoItem;
import net.noodles.noodlesmusketrm.NoodlesmusketrmMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

public class NoodlesmusketrmModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, NoodlesmusketrmMod.MODID);
	public static final RegistryObject<Item> MUSKET = REGISTRY.register("musket", () -> new TESTItem());
	public static final RegistryObject<Item> THROUGH_BAR = REGISTRY.register("through_bar", () -> new ThroughBarItem());
	public static final RegistryObject<Item> AMMO = REGISTRY.register("ammo", () -> new AmmoItem());
	public static final RegistryObject<Item> BARREL = REGISTRY.register("barrel", () -> new BarrelItem());
	public static final RegistryObject<Item> BASE = REGISTRY.register("base", () -> new BASEItem());
	public static final RegistryObject<Item> NETHERITE_MUSKET = REGISTRY.register("netherite_musket", () -> new NetheriteMusketItem());
	public static final RegistryObject<Item> MUSKET_NETHERITE = REGISTRY.register("musket_netherite", () -> new MusketNetheriteItem());
	public static final RegistryObject<Item> OTTOMAN_FLAG = block(NoodlesmusketrmModBlocks.OTTOMAN_FLAG);
	public static final RegistryObject<Item> FRANCE_FLAG = block(NoodlesmusketrmModBlocks.FRANCE_FLAG);
	public static final RegistryObject<Item> BRITISH_FLAG = block(NoodlesmusketrmModBlocks.BRITISH_FLAG);
	public static final RegistryObject<Item> TSARIST_RUSSIA_FLAG = block(NoodlesmusketrmModBlocks.TSARIST_RUSSIA_FLAG);
	public static final RegistryObject<Item> PRUSSIA_FLAG = block(NoodlesmusketrmModBlocks.PRUSSIA_FLAG);

	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}

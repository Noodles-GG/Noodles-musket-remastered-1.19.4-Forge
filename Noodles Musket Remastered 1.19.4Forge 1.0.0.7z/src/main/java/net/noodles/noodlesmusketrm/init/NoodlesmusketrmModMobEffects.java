
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.noodles.noodlesmusketrm.init;

import net.noodles.noodlesmusketrm.potion.PrussiaSoulMobEffect;
import net.noodles.noodlesmusketrm.potion.OttoEfMobEffect;
import net.noodles.noodlesmusketrm.potion.FranceSoulMobEffect;
import net.noodles.noodlesmusketrm.potion.BritishSoulMobEffect;
import net.noodles.noodlesmusketrm.NoodlesmusketrmMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.effect.MobEffect;

public class NoodlesmusketrmModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, NoodlesmusketrmMod.MODID);
	public static final RegistryObject<MobEffect> PRUSSIA_SOUL = REGISTRY.register("prussia_soul", () -> new PrussiaSoulMobEffect());
	public static final RegistryObject<MobEffect> OTTO_EF = REGISTRY.register("otto_ef", () -> new OttoEfMobEffect());
	public static final RegistryObject<MobEffect> FRANCE_SOUL = REGISTRY.register("france_soul", () -> new FranceSoulMobEffect());
	public static final RegistryObject<MobEffect> BRITISH_SOUL = REGISTRY.register("british_soul", () -> new BritishSoulMobEffect());
}


/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.noodles.noodlesmusketrm.init;

import net.noodles.noodlesmusketrm.block.TsaristRussiaFlagBlock;
import net.noodles.noodlesmusketrm.block.PrussiaFlagBlock;
import net.noodles.noodlesmusketrm.block.OttomanFlagBlock;
import net.noodles.noodlesmusketrm.block.FranceFlagBlock;
import net.noodles.noodlesmusketrm.block.BritishFlagBlock;
import net.noodles.noodlesmusketrm.NoodlesmusketrmMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

public class NoodlesmusketrmModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, NoodlesmusketrmMod.MODID);
	public static final RegistryObject<Block> OTTOMAN_FLAG = REGISTRY.register("ottoman_flag", () -> new OttomanFlagBlock());
	public static final RegistryObject<Block> FRANCE_FLAG = REGISTRY.register("france_flag", () -> new FranceFlagBlock());
	public static final RegistryObject<Block> BRITISH_FLAG = REGISTRY.register("british_flag", () -> new BritishFlagBlock());
	public static final RegistryObject<Block> TSARIST_RUSSIA_FLAG = REGISTRY.register("tsarist_russia_flag", () -> new TsaristRussiaFlagBlock());
	public static final RegistryObject<Block> PRUSSIA_FLAG = REGISTRY.register("prussia_flag", () -> new PrussiaFlagBlock());
}

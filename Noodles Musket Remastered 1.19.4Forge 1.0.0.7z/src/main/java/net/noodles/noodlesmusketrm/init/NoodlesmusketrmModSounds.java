
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.noodles.noodlesmusketrm.init;

import net.noodles.noodlesmusketrm.NoodlesmusketrmMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;

public class NoodlesmusketrmModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, NoodlesmusketrmMod.MODID);
	public static final RegistryObject<SoundEvent> CLEAN_MUSKET = REGISTRY.register("clean_musket", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("noodlesmusketrm", "clean_musket")));
	public static final RegistryObject<SoundEvent> MUSKET_FIRE = REGISTRY.register("musket_fire", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("noodlesmusketrm", "musket_fire")));
}


/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.noodles.noodlesmusketrm.init;

import net.noodles.noodlesmusketrm.world.inventory.UpgradeGUIMenu;
import net.noodles.noodlesmusketrm.world.inventory.LoadMenu;
import net.noodles.noodlesmusketrm.NoodlesmusketrmMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.extensions.IForgeMenuType;

import net.minecraft.world.inventory.MenuType;

public class NoodlesmusketrmModMenus {
	public static final DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.MENU_TYPES, NoodlesmusketrmMod.MODID);
	public static final RegistryObject<MenuType<LoadMenu>> LOAD = REGISTRY.register("load", () -> IForgeMenuType.create(LoadMenu::new));
	public static final RegistryObject<MenuType<UpgradeGUIMenu>> UPGRADE_GUI = REGISTRY.register("upgrade_gui", () -> IForgeMenuType.create(UpgradeGUIMenu::new));
}

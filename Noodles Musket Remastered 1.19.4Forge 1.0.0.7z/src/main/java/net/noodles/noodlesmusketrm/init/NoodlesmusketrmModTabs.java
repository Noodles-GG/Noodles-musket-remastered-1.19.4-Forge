
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.noodles.noodlesmusketrm.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.CreativeModeTabEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class NoodlesmusketrmModTabs {
	@SubscribeEvent
	public static void buildTabContentsModded(CreativeModeTabEvent.Register event) {
		event.registerCreativeModeTab(new ResourceLocation("noodlesmusketrm", "musket"),
				builder -> builder.title(Component.translatable("item_group.noodlesmusketrm.musket")).icon(() -> new ItemStack(NoodlesmusketrmModItems.MUSKET.get())).displayItems((parameters, tabData) -> {
					tabData.accept(NoodlesmusketrmModItems.THROUGH_BAR.get());
					tabData.accept(NoodlesmusketrmModItems.AMMO.get());
					tabData.accept(NoodlesmusketrmModItems.BARREL.get());
					tabData.accept(NoodlesmusketrmModItems.BASE.get());
					tabData.accept(NoodlesmusketrmModItems.MUSKET_NETHERITE.get());
					tabData.accept(NoodlesmusketrmModBlocks.OTTOMAN_FLAG.get().asItem());
					tabData.accept(NoodlesmusketrmModBlocks.FRANCE_FLAG.get().asItem());
					tabData.accept(NoodlesmusketrmModBlocks.BRITISH_FLAG.get().asItem());
					tabData.accept(NoodlesmusketrmModBlocks.TSARIST_RUSSIA_FLAG.get().asItem());
					tabData.accept(NoodlesmusketrmModBlocks.PRUSSIA_FLAG.get().asItem());
				})

		);
	}
}

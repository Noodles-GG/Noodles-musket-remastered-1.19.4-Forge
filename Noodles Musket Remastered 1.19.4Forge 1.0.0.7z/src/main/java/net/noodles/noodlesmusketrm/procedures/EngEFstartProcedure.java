package net.noodles.noodlesmusketrm.procedures;

import net.minecraftforge.common.ForgeMod;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerPlayer;

public class EngEFstartProcedure {
	public static void execute(double x, double z, Entity entity) {
		if (entity == null)
			return;
		((LivingEntity) entity).getAttribute(ForgeMod.SWIM_SPEED.get()).setBaseValue((((LivingEntity) entity).getAttribute(ForgeMod.SWIM_SPEED.get()).getBaseValue() - 0.25));
		if (Math.abs((entity instanceof ServerPlayer _player && !_player.level.isClientSide())
				? ((_player.getRespawnDimension().equals(_player.level.dimension()) && _player.getRespawnPosition() != null) ? _player.getRespawnPosition().getX() : _player.level.getLevelData().getXSpawn())
				: 0) - Math.abs(x) > 1000
				&& Math.abs((entity instanceof ServerPlayer _player && !_player.level.isClientSide())
						? ((_player.getRespawnDimension().equals(_player.level.dimension()) && _player.getRespawnPosition() != null) ? _player.getRespawnPosition().getZ() : _player.level.getLevelData().getZSpawn())
						: 0) - Math.abs(z) > 1000) {
			((LivingEntity) entity).getAttribute(ForgeMod.SWIM_SPEED.get())
					.setBaseValue((0.2 + Math.max(Math.abs(Math.cbrt((Math.abs((entity instanceof ServerPlayer _player && !_player.level.isClientSide())
							? ((_player.getRespawnDimension().equals(_player.level.dimension()) && _player.getRespawnPosition() != null) ? _player.getRespawnPosition().getX() : _player.level.getLevelData().getXSpawn())
							: 0) - Math.abs(x)) / 8.5)), 1) + ((LivingEntity) entity).getAttribute(ForgeMod.SWIM_SPEED.get()).getBaseValue()));
			((LivingEntity) entity).getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.ARMOR_TOUGHNESS)
					.setBaseValue((1 + Math.max(Math.abs(Math.cbrt((Math.abs(x) - Math.abs((entity instanceof ServerPlayer _player && !_player.level.isClientSide())
							? ((_player.getRespawnDimension().equals(_player.level.dimension()) && _player.getRespawnPosition() != null) ? _player.getRespawnPosition().getX() : _player.level.getLevelData().getXSpawn())
							: 0)) / 2)), 6) + ((LivingEntity) entity).getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.ARMOR_TOUGHNESS).getBaseValue()));
			((LivingEntity) entity).getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.ARMOR)
					.setBaseValue((1 + Math.max(Math.abs(Math.cbrt((Math.abs(x) - Math.abs((entity instanceof ServerPlayer _player && !_player.level.isClientSide())
							? ((_player.getRespawnDimension().equals(_player.level.dimension()) && _player.getRespawnPosition() != null) ? _player.getRespawnPosition().getX() : _player.level.getLevelData().getXSpawn())
							: 0)) / 3)), 4) + ((LivingEntity) entity).getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.ARMOR).getBaseValue()));
		}
	}
}

package net.noodles.noodlesmusketrm.procedures;

import net.noodles.noodlesmusketrm.network.NoodlesmusketrmModVariables;

import net.minecraft.world.entity.Entity;

public class OttomanOverProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		{
			double _setval = 1;
			entity.getCapability(NoodlesmusketrmModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
				capability.LoadSpeed = _setval;
				capability.syncPlayerVariables(entity);
			});
		}
	}
}

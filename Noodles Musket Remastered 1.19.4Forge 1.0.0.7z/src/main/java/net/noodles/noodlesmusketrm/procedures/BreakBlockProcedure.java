package net.noodles.noodlesmusketrm.procedures;

import net.noodles.noodlesmusketrm.configuration.MusketDamageConfiguration;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.BlockPos;

public class BreakBlockProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		if (MusketDamageConfiguration.BREAK_WEAK_BLOCK.get() == true) {
			if (world.getBlockState(BlockPos.containing(x, y, z)).getDestroySpeed(world, BlockPos.containing(x, y, z)) <= 0.45) {
				world.destroyBlock(BlockPos.containing(x, y, z), false);
				if (world instanceof ServerLevel _level)
					_level.sendParticles(ParticleTypes.CLOUD, x, y, z, 8, 0.3, 0.15, 0.3, 0.1);
			}
		}
	}
}

package net.noodles.noodlesmusketrm.procedures;

import net.noodles.noodlesmusketrm.network.NoodlesmusketrmModVariables;
import net.noodles.noodlesmusketrm.configuration.MusketDamageConfiguration;

import net.minecraft.world.entity.Entity;

public class OttoStartProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		{
			double _setval = 1 + (double) MusketDamageConfiguration.OTTOMAN_LOAD_FASTER.get();
			entity.getCapability(NoodlesmusketrmModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
				capability.LoadSpeed = _setval;
				capability.syncPlayerVariables(entity);
			});
		}
	}
}

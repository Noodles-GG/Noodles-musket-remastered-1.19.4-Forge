package net.noodles.noodlesmusketrm.procedures;

public class EngENDstartProcedure {
	public static void execute() {
	}
}

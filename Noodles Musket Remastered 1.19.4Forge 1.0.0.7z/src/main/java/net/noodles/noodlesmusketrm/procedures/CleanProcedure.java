package net.noodles.noodlesmusketrm.procedures;

import net.noodles.noodlesmusketrm.network.NoodlesmusketrmModVariables;
import net.noodles.noodlesmusketrm.configuration.MusketDamageConfiguration;

import net.minecraftforge.registries.ForgeRegistries;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.util.RandomSource;
import net.minecraft.tags.ItemTags;
import net.minecraft.sounds.SoundSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.BlockPos;

public class CleanProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).is(ItemTags.create(new ResourceLocation("forge:musket"))) == true) {
			if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getOrCreateTag().getBoolean("clean") == false) {
				if (entity instanceof Player _player)
					_player.getCooldowns().addCooldown((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem(),
							(int) ((90 / (double) MusketDamageConfiguration.MULTI.get()) / (entity.getCapability(NoodlesmusketrmModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new NoodlesmusketrmModVariables.PlayerVariables())).LoadSpeed));
				if (entity instanceof Player _player)
					_player.getCooldowns().addCooldown((entity instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY).getItem(),
							(int) ((90 / (double) MusketDamageConfiguration.MULTI.get()) / (entity.getCapability(NoodlesmusketrmModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new NoodlesmusketrmModVariables.PlayerVariables())).LoadSpeed));
				if (entity instanceof Player _player)
					_player.causeFoodExhaustion((float) 0.5);
				if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
					_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN,
							(int) ((90 / (double) MusketDamageConfiguration.MULTI.get()) / (entity.getCapability(NoodlesmusketrmModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new NoodlesmusketrmModVariables.PlayerVariables())).LoadSpeed),
							(int) (double) MusketDamageConfiguration.SLOW_LEVEL.get(), false, false));
				{
					ItemStack _ist = (entity instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY);
					if (_ist.hurt(1, RandomSource.create(), null)) {
						_ist.shrink(1);
						_ist.setDamageValue(0);
					}
				}
				if (world instanceof Level _level) {
					if (!_level.isClientSide()) {
						_level.playSound(null, BlockPos.containing(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("noodlesmusketrm:clean_musket")), SoundSource.PLAYERS, (float) 2.5, (float) 1.3);
					} else {
						_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("noodlesmusketrm:clean_musket")), SoundSource.PLAYERS, (float) 2.5, (float) 1.3, false);
					}
				}
				if (world instanceof ServerLevel _level)
					_level.sendParticles(ParticleTypes.LARGE_SMOKE, x, (y + 1.25), z,
							(int) ((90 / (double) MusketDamageConfiguration.MULTI.get()) / (entity.getCapability(NoodlesmusketrmModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new NoodlesmusketrmModVariables.PlayerVariables())).LoadSpeed),
							0.2, 0.1, 0.2, 0.05);
				(entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getOrCreateTag().putBoolean("clean", true);
				if (entity instanceof Player _player && !_player.level.isClientSide())
					_player.displayClientMessage(Component.literal("\u6E05\u7406\u5B8C\u6BD5\uFF01"), true);
			}
		}
	}
}
